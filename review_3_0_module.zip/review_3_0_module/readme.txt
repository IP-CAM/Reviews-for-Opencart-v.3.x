Upload this via ftp

All reviews should be available from link 
www.your-site.com/index.php?route=catalog/review